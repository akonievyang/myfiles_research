<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
        <title>Sanbunna Slide show</title>
        <script src="sliderengine/jquery.js"></script>
        <script src="sliderengine/amazingslider.js"></script>
        <script src="sliderengine/initslider-1.js"></script>
    </head>
    <body style="background-color:#aaa;">
        <div style="margin:60px auto;max-width:1024px;">
            <div id="amazingslider-1" style="display:block;position:relative;margin:15px auto 30px;">
                <ul class="amazingslider-slides" style="display:none;">
                    <li><img src="images/Slide2.png" /> </li>
                    <li><img src="images/Slide1.png" /></li>
                </ul>
            </div>
        </div>
    </body>
</html>