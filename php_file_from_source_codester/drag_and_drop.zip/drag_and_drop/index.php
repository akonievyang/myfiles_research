<?php 
include('header.php');
?>
<body>

    <div class="row-fluid">
        <div class="span12">


         

            <div class="container">
    <div class="row">
    <div class="span8">

	<div class="alert alert-info">Drag the image to the trash Can to Delete it.</div>
	<?php
					
					$result = mysql_query("SELECT * FROM image order by id");
					while($row=mysql_fetch_assoc($result))
					{
				
					
						echo '<div class="picture"><img class="img-rounded" src="img/'.$row['img'].'" width="128" height="128" class="pngfix" /></div>';
						
					}

					?>
	
	</div>
    <div class="span4">
	
					<div class="content drop-here">
					
					<i class="icon-trash" height="100"></i>
						<img src="img/e.png" alt="shopping cart" class="pngfix" width="128" height="128" />
					</div>

			
		
		
			
	
	</div>
    </div>


	

		
		
	
			
			
					
					
					

			

			
		
			


	
	
	
	
	</div>
	
</div>


          
        
       
        </div>
 



</body>
</html>


