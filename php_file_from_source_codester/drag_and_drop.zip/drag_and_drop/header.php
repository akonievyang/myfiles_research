<!DOCTYPE html>
<html lang="en">
    <head>

        <title>Drag and drop delete</title>

        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
   
     
       

<link rel="stylesheet" type="text/css" href="css/demo.css" />
</head>

<script src="js/bootstrap.js" type="text/javascript"></script>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery_ui.js"></script>

<script type="text/javascript" src="js/simpletip.js"></script>


<script type="text/javascript" src="js/delete.js"></script>
<?php 
include('connect.php');
?>

