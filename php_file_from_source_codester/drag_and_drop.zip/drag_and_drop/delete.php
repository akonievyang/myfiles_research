<?php

require "connect.php";


$img=mysql_real_escape_string(end(explode('/',$_POST['img'])));
$row=mysql_fetch_assoc(mysql_query("delete FROM image WHERE img='".$img."'"));


?>

