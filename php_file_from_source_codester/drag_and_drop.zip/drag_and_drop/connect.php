<?php

mysql_select_db('drag_and_drop',mysql_connect('localhost','root',''))or die(mysql_error());

?>