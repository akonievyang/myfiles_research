<!DOCTYPE html>
<html>
<head>

<title>Sum_number_in_a_Column</title>
 <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
</head>
<?php
include('dbcon.php');
?>