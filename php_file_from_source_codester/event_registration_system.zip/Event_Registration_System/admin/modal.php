    <!-- Modal -->
    <div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">

    </div>
    <div class="modal-body">
    <p>Are you sure you want to Logout?</p>
    </div>
    <div class="modal-footer">
    <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i>&nbsp;Close</button>
    <a href="logout.php" class="btn btn-danger"><i class="icon-signout"></i>&nbsp;Logout</a>
    </div>
    </div>