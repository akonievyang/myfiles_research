<?php 
include('header.php');
?>
<body>
 <div class="navbar  navbar-fixed-top">
    <div class="navbar-inner1">

    </div>
    </div>
<div class="container">

<br>
<br>
<br>
<br>

   
<div class="thumbnail">
     <div class="row">
	<div class="span3 offset1">.</div>
    <div class="span8">
	<br>
	
	<div class="alert alert-info"><strong><i class="icon-file"></i>&nbsp;Please Fill up all the details Below</strong></div>
	
	 <form class="form-horizontal" method="POST">
    <div class="control-group">
    <label class="control-label" for="inputEmail">FirstName</label>
    <div class="controls">
    <input type="text" class="span4" name="fn" id="inputEmail" placeholder="FirstName" required>
    </div>
    </div>
	  <div class="control-group">
    <label class="control-label" for="inputEmail">LastName</label>
    <div class="controls">
    <input type="text" class="span4" name="ln" id="inputEmail" placeholder="LastName" required>
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail">Age</label>
    <div class="controls">
    <input type="text" class="span1" name="age" id="inputEmail" placeholder="Age" required>
    </div>
    </div>
	 
	 <div class="control-group">
    <label class="control-label" for="inputEmail">Gender</label>
    <div class="controls">
	<select class="span2" name="gender" required>
	<option></option>
	<option>Male</option>
	<option>Female</option>
	</select>
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail">Address</label>
    <div class="controls">
    <input type="text" class="span4" name="address" id="inputEmail" placeholder="Address" required>
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail">Email Adress</label>
    <div class="controls">
    <input type="text" class="span4" name="email" id="inputEmail" placeholder="Email Address" required>
    </div>
    </div>
	
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail">Contact Number</label>
    <div class="controls">
    <input type="text" class="span4" name="c_number" id="inputEmail" placeholder="Contact Number" required>
    </div>
    </div>
 
    <div class="control-group">
    <div class="controls">

    <button type="submit" name="submit" class="btn btn-success"><i class="icon-save icon-large"></i>&nbsp;Submit</button>
    </div>
    </div>
    </form>
	</div>
    <div class="span2">.</div>
    </div>
	</div>
	   <div class="navbar navbar-inverse">
    <div class="navbar-inner ">
   <center id="color_white">
	Programmed by:John kevin Lorayna :-P
   </center>
    </div>
    </div>
	
	<?php
	if (isset($_POST['submit'])){
	$fn=$_POST['fn'];
	$ln=$_POST['ln'];
	$age=$_POST['age'];
	$gender=$_POST['gender'];
	$address=$_POST['address'];
	$email=$_POST['email'];
	$c_number=$_POST['c_number'];
	
	mysql_query("insert into reg_member (firstname,lastname,age,address,gender,email,c_number,date)
	values('$fn','$ln','$age','$address','$gender','$email','$c_number',NOW())
	")or die(mysql_error());
	?>
	<script type="text/javascript">
	alert('You are Successfully Register Thank You');
	window.location="index.php";
	</script>

	<?php
	}
	?>
	
	
</div>
</body>
</html>