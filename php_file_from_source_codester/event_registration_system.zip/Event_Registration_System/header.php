<!DOCTYPE html>
<html lang="en">
    <head>

        <title>Event_Registration_System</title>
   
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
        <link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="screen">
        <link href="css/DT_bootstrap.css" rel="stylesheet" type="text/css" media="screen">
       
       
    </head>
	   <script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.js" type="text/javascript"></script>
 
    <script src="js/bootstrap-tab.js" type="text/javascript"></script>
    <script src="js/bootstrap-transition.js" type="text/javascript"></script>
    <script src="js/DT_bootstrap.js" type="text/javascript"></script>
    <script src="js/jquery.dataTables.js" type="text/javascript"></script>
 

<?php 
include('dbcon.php');
?>