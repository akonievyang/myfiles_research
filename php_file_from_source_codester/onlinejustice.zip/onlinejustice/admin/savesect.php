<?php
	session_start();
	//Include database connection details
	include("dbConnector.php");
	include("sessions.php");
	
	$connector = new DbConnector();
	
	//Array to store validation errors
	$errmsg_arr = array();
	
	//Validation error flag
	$errflag = false;
	
	
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
	
	//Sanitize the POST values
	$sectno = clean($_POST['sectno']);
	$secttext = clean($_POST['secttext']);
	$id2=$_GET['id2'];
	
	if($id2 == '') {
		$errmsg_arr[] = 'chapter number field is missing';
		$errflag = true;
	}
	
	if($secttext == '') {
		$errmsg_arr[] = 'section text field is missing';
		$errflag = true;
	}
	if($sectno == '') {
		$errmsg_arr[] = 'section number field is missing';
		$errflag = true;
	}


//Check for duplicate login ID
	if($sectno!= '') {
		$qry = "SELECT * FROM sections WHERE secno='$sectno' or title='$secttext'";
		//$result = mysql_query($qry);
		$result = $connector->query($qry);
		if($result) {
			if(mysql_num_rows($result) > 0) {
				$errmsg_arr[] = ' section is already in use, please select another one';
				$errflag = true;
			}
			@mysql_free_result($result);
		}
		else {
			die("Query failed, couldn't verify duplicate username on the database");
		}
	}
//If there are input validations, redirect back to the registration form
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: addsect.php?id=$id2");
		exit();
	}
	
	
	//Create INSERT query
	$qry2 = "INSERT INTO sections (capno,secno,title) VALUES ('$id2','$sectno','$secttext')";
	
		//$result = @mysql_query($qry);
	    $result2 = $connector->query($qry2);
	//Check whether the query was successful or not
	if($result2) {
		$errmsg_arr[] = 'section '. $sectno. ' was created Successfully!';
		$errflag = true;
		if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: addsect.php?id=$id2");
		exit();
	}

			
		header("location: addsect.php?id=$id2");
		exit();
	}else {
		die("Query failed, couldnt add the record");
		header("location: addsect.php?id=$id2");
		exit();
	}
	
	mysql_close();
?>


