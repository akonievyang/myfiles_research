<?php
include("dbConnector.php");
$connector = new DbConnector();

$username = trim($_POST['username']);
$username = mysql_escape_string($username);

$query = "SELECT username FROM user WHERE username = '$username' LIMIT 1";
$result = $connector->query($query);
//$num = mysql_num_rows($result);

//echo $num;


if(mysql_num_rows($result))
{
echo '1';//If there is a  record match in the Database - Not Available
}
else
{
echo '0';//No Record Found - Username is available 
}

mysql_close();
?>