<?php
	session_start();
	//Include database connection details

    include("dbConnector.php");
	$connector = new DbConnector();
	
	//Array to store validation errors
	$errmsg_arr = array();
	
	//Validation error flag
	$errflag = false;
	
	
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
	
	//Sanitize the POST values

	$username = clean($_POST['usernameget']);
	$captcha = clean($_POST['secCodeget']);
	$secqstn = clean($_POST['secqstnget']);
	$secans = clean($_POST['secansget']);
	
	//Input Validations
if ($captcha != $_SESSION['securityCode']) {
	//Note: the captcha code is compared case insensitively.
	//if you want case sensitive match, update the check above to
	// strcmp()
		$errmsg_arr[] = 'captcha code is missing or incorrect';
		$errflag = true;
	}
		if($secans == '') {
		$errmsg_arr[] = 'security question answer field is missing';
		$errflag = true;
	}
		if($username == '') {
		$errmsg_arr[] = 'username field is missing';
		$errflag = true;
	}
	if($secqstn == '') {
		$errmsg_arr[] = 'security question field is missing';
		$errflag = true;
	}


//Check for duplicate login ID
	if($username!= '') {
		$qry = "SELECT * FROM user WHERE username='$username'and secqsn='$secqstn' and secans='".md5($secans)."'";
		//$result = mysql_query($qry);
		$result = $connector->query($qry);
		if($result) {
			if(mysql_num_rows($result) > 0) {
		
			  while($row = mysql_fetch_assoc($result))
					{ $password= $row['password']; }
				$errmsg_arr[] = $password .' is your password go to http://www.decrypt-md5.com/ to unencrypt password ';
				$errflag = true;
			}
			@mysql_free_result($result);
		}
		else {
			//die("Query failed, couldnt retrieve your password");
			$errmsg_arr[] = 'couldnt retrieve your password, please enter valid details';
			$errflag = true;
		}
	}
//If there are input validations, redirect back to the registration form
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: index.php#tabs-3");
		exit();
	}
	
	
?>

