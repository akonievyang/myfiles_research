Place all files in the same directory (important), then load either webforms2.js or webforms2-p.js into your page.

For the latest version, implementation details, usage information, and a test suite, see: http://code.google.com/p/webforms2/