

<?php
	//Start session
	session_start();
	
	//Include database connection details
	include("dbConnector.php");
	$connector = new DbConnector();
	
	//Array to store validation errors
	$errmsg_arr = array();
	
	//Validation error flag
	$errflag = false;
	
	if (isset($_GET["action"]) && ($_GET["action"] == "login")) {
	
		
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
	
	//Sanitize the POST values
	$userid = clean($_POST['loginname']);
	$passcode = clean($_POST['loginkey']);
	$code = clean($_POST['secCode1']);
	//Input Validations
	if($userid == '') {
		$errmsg_arr[] = 'Login ID missing';
		$errflag = true;
	}
	if($passcode == '') {
		$errmsg_arr[] = 'Password missing';
		$errflag = true;
	}
	if ($code != $_SESSION['securityCode']) {
	//Note: the captcha code is compared case insensitively.
	//if you want case sensitive match, update the check above to
	// strcmp()
		$errmsg_arr[] = 'captcha code is missing or incorrect';
		$errflag = true;
	}
	//If there are input validations, redirect back to the login form
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: index.php");
		exit();
	}
	//un-encrypt password
	$encpass=md5($passcode);
	//Create query
	$qry="SELECT * FROM user WHERE username='$userid' AND password='".md5($passcode)."'";
	//$result=mysql_query($qry);
	$result = $connector->query($qry);
	//Check whether the query was successful or not
	if($result) {
		if(mysql_num_rows($result) > 0) {
		session_register('is');
		$_SESSION['is']['login']    = TRUE;
		$_SESSION['is']['username'] = $_POST['loginname'];
	    $session = "1";	
			session_write_close();
			header("location: index2.php");
			exit();
		}else {
			//Login failed
			//header("location: accessdenied.php");
			//exit();
		$errmsg_arr[] = 'Enter correct login details';
		$errflag = true;
		if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: index.php#tabs-1");
		exit();
	}
		}
	}else {
		die("Query failed, couldnt complete the query");

	}
	}
	else {
	header("location: denied.php");
			exit();
	}
	
	mysql_close();
?>

