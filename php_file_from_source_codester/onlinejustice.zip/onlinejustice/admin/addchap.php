<?php
	session_start();
	//Include database connection details
	include("dbConnector.php");
	include("sessions.php");
	
	$connector = new DbConnector();
	
	//Array to store validation errors
	$errmsg_arr = array();
	
	//Validation error flag
	$errflag = false;
	
	
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
	
	//Sanitize the POST values
	$chapno = clean($_POST['chapno']);
	$chaptext = clean($_POST['chaptext']);
	
	if($chapno == '') {
		$errmsg_arr[] = 'chapter number field is missing';
		$errflag = true;
	}
	if($chaptext == '') {
		$errmsg_arr[] = 'chapter text field is missing';
		$errflag = true;
	}



//Check for duplicate login ID
	if($chapno!= '') {
		$qry = "SELECT * FROM chapters WHERE capno='$chapno' or title='$chaptext'";
		//$result = mysql_query($qry);
		$result = $connector->query($qry);
		if($result) {
			if(mysql_num_rows($result) > 0) {
				$errmsg_arr[] = ' chapter number already in use, please select another one';
				$errflag = true;
			}
			@mysql_free_result($result);
		}
		else {
			die("Query failed, couldn't verify duplicate username on the database");
		}
	}
//If there are input validations, redirect back to the registration form
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: index2.php#tabs-1");
		exit();
	}
	
	
	//Create INSERT query
	$qry2 = "INSERT INTO chapters (capno,title) VALUES ('$chapno','$chaptext')";
	
		//$result = @mysql_query($qry);
	    $result2 = $connector->query($qry2);
	//Check whether the query was successful or not
	if($result2) {
		$errmsg_arr[] = 'chapter was created Successfully!';
		$errflag = true;
		if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: index2.php#tabs-1");
		exit();
	}

			
		header("location: index2.php#tabs-1");
		exit();
	}else {
		die("Query failed, couldnt add the record");
		header("location: index2.php#tabs-1");
		exit();
	}
	
	mysql_close();
?>


