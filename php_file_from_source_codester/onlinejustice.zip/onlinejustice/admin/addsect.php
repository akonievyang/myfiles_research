<?php 
session_start();
$id=$_GET['id'];
include("sessions.php"); 

include("dbconnector.php"); 
$connector = new DbConnector();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Justice :: Uganda Constitution</title>
<link href="css/page-styling.css" rel="stylesheet" type="text/css" media="screen"  />
<link href="css/jquery_notification.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/themes/cupertino/jquery.ui.all.css" type="text/css">

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.watermarkinput.js"></script>
<script type="text/javascript" src="js/jquery_notification_v.1.js"></script>
<script type="text/javascript" src="js/jquery.watermarkinput.js"></script>
<script type="text/javascript" src="js/ui/jquery.ui.core.js"></script>
<script type="text/javascript" src="js/ui/jquery.ui.widget.js"></script>
<script type="text/javascript" src="js/ui/jquery.ui.tabs.js"></script>
<script type="text/javascript" src="js/ui/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="js/modernizr-2.0.6.js"></script>
<script type="text/javascript" src="js/webforms2-0.5.4/webforms2.js"></script>
<script src="js/tooltip-inputboxes.js" type="text/javascript"></script>
<script type="text/javascript">
	$(function() {
		$("#tabs").tabs();
	});
	</script>
<script type="text/javascript">
            $(document).ready(function(){
			 showErrorMessage();
            });
</script>
 

<script type="text/javascript">
	$(function() {
		$('#datepicker').datepicker();
	});
	</script>
</head>

<body>
<script type="text/javascript">
        function showErrorMessage(){
        showNotification({
        type : "information",
        message: "Add Sections of Chapter - <?php echo $id; ?>",
		autoClose: true,
        duration: 5 
                                    });    
                                }                                
        </script> 
<table width="980" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="3">
    <div class="logo"> <img src="images/logo.png" alt="logo" /></div>
    <div class="tagline"><h2> Electronic Ugandan Constitution </h2> 
    <br />
    Hi <?php echo $user; ?>, <a href="logout.php">Sign out</a></div>
    <div></div>
    </td>
  </tr>
  <tr>
     <td width="200">
     </td>
    <td align="" width="580">
    <div id="error" style="width:380px;">
    <?php
	if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
		
		foreach($_SESSION['ERRMSG_ARR'] as $msg) {
			echo '<img src="images/ex.png"> - <strong><font color="red">',$msg ,'</font></strong>'; 
		}
		unset($_SESSION['ERRMSG_ARR']);
	}
?>
    </div>
    <div id="tabs" style="font-size:12px; ">
    <ul>
		<li><a href="#tabs-1">Add Sections of Chapter - <?php echo $id; ?></a></li>
    </ul>
    <div align="" style="" id="tabs-1">
    <!-- chapters -->
    <h3> <a href="index2.php" title="go to main page">Go back</a> </h3>
    <div id="existingchapters">
    <table style="border:thin; border-color:#990; border-style:solid; " width="580">
    <tr>
    <td style="border:thin; border-color:#990; border-style:solid; "><strong>Chapter Number</strong></td> <td style="border:thin; border-color:#990; border-style:solid; "> <strong>Chapter Title</strong></td>     
    <tr>
    <?php
		$qry1 = "SELECT * from chapters WHERE capno='$id'";
	
		//$result = @mysql_query($qry);
	    $result1 = $connector->query($qry1);
		
		 while($data1 = mysql_fetch_assoc($result1))
	{
		echo "<tr> <td style='border:thin; border-color:#990; border-style:solid;'>{$data1['capno']} </td> <td style='border:thin; border-color:#990; border-style:solid;'>{$data1['title']} </td> 
		 </tr>";
        	$qry2="SELECT * from sections WHERE capno='$id'";
			$result2 = $connector->query($qry2);
		 while($data2 = mysql_fetch_assoc($result2)) {
	         
	    echo "<tr> <td colspan='2'> 
		<table width='580' > 
<tr><td width='100' style='border:thin; border-color:#C60; border-style:solid;'><strong>Section Number</strong> </td> 

<td width='380' style='border:thin; border-color:#C60; border-style:solid;'> <strong>Section Title</strong></td> 

<td style='border:thin; border-color:#C60; border-style:solid;' width='100'><strong>Section Operations</strong> </td>
</tr> 

<tr> 
<td width='100' style='border:thin; border-color:#C60; border-style:solid;'> {$data2['secno']} </td> 

<td width='380' style='border:thin; border-color:#C60; border-style:solid;'> {$data2['title']} </td> 

<td style='border:thin; border-color:#C60; border-style:solid;' width='100'><a href='editcect.php?sec={$data2['secno']}' title='edit this section'>Edit Section </a>
<br>
<a href='addclause.php?sec={$data2['secno']}&cap={$data2['capno']}' title='edit this section'>Add Clauses </a>
 </td></tr></table> </td></tr>";
	
					 }
	?>
    </table>
    </div>
    <div> 
    <br />
    <h3> Add Sections of this chapter</h3> 
    </div>
    <div id="addnewchapters">
    <form action="savesect.php?id2=<?php echo "{$data1['capno']}";?>" method="post" name="editchapters">
    <label>Chapter Number</label> <br /> <input name="chapno" type="text" class="tooltip" title="Enter the chapter number " required value="<?php echo "{$data1['capno']}";?>" disabled="disabled"/> <br />
    <label>Section Number</label> <br /> <input name="sectno" type="text" class="tooltip" title="Enter the chapter number " maxlength="" required  /> <br />
    <label>Section Title</label> <br />
    <textarea name="secttext" class="tooltip" cols="43" rows="10" title="Enter the chapter text " required="required"></textarea>
     <br />
     <br />
    <input name="Save" type="submit" value="Save" />
    </form>
    <?php } ?>
    </div>
    
    </div>
   
    
    
    
    </div>
    </td>
    <td width="200">
    </td>
  </tr>
    <tr>
    <td colspan="3">
    <div>
    &nbsp;
    </div>
    </td>
  </tr>
  <tr>
    <td colspan="3">
    <div class="footer" style="background-image:url(images/footer.png); float:right; width:230px; height:170px; ">
    
    </div>
    </td>
  </tr>
  
</table>
</body>
</html>
