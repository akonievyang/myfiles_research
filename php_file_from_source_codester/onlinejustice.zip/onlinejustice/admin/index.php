<?php 
session_start();

include ("dbconnector.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Justice :: Uganda Constitution</title>
<link href="css/page-styling.css" rel="stylesheet" type="text/css" media="screen"  />
<link href="css/jquery_notification.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/themes/cupertino/jquery.ui.all.css" type="text/css">

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.watermarkinput.js"></script>
<script type="text/javascript" src="js/jquery_notification_v.1.js"></script>
<script type="text/javascript" src="js/jquery.watermarkinput.js"></script>
<script type="text/javascript" src="js/ui/jquery.ui.core.js"></script>
<script type="text/javascript" src="js/ui/jquery.ui.widget.js"></script>
<script type="text/javascript" src="js/ui/jquery.ui.tabs.js"></script>
<script type="text/javascript" src="js/ui/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="js/modernizr-2.0.6.js"></script>
<script type="text/javascript" src="js/webforms2-0.5.4/webforms2.js"></script>
<script src="js/tooltip-inputboxes.js" type="text/javascript"></script>
<script type="text/javascript">
	$(function() {
		$("#tabs").tabs();
	});
	</script>
<script type="text/javascript">
            $(document).ready(function(){
			 showErrorMessage();
            });
</script>
 
<script type="text/javascript">
$(document).ready(function()//When the dom is ready 
{

$("#username").keyup(function() 
{ //if theres a change in the username textbox

var username = $("#username").val();//Get the value in the username textbox
if(username.length > 3)//if the lenght greater than 3 characters
{
$("#availability_status").html('<img src="images/ajax_small.gif" align="absmiddle">&nbsp;Checking availability...');
//Add a loading image in the span id="availability_status"

$.ajax({  //Make the Ajax Request
    type: "POST",  
    url: "check-username.php",  //file name
    data: "username="+ username,  //data
    success: function(server_response){  
   
   $("#availability_status").ajaxComplete(function(event, request){ 

	if(server_response == '0')//if ajax_check_username.php return value "0"
	{ 
	$("#availability_status").html('<img src="images/tick.png" align="absmiddle"> <font color="Green"> Username is Available </font>  ');
	//add this image to the span with id "availability_status"
	}  
	else  if(server_response == '1')//if it returns "1"
	{  
	 $("#availability_status").html('<img src="images/cross.png" align="absmiddle"> <font color="red">Username is Not Available </font>');
	}  
   
   });
   } 
   
  }); 

}
else
{

$("#availability_status").html('<img src="cross.png" align="absmiddle"><font color="#cc0000">Username is too short</font>');
//if in case the username is less than or equal 3 characters only 
}



return false;
});

});
</script>       


<script type="text/javascript">
	$(function() {
		$('#datepicker').datepicker();
	});
	</script>
</head>

<body>
<script type="text/javascript">
        function showErrorMessage(){
        showNotification({
        type : "information",
        message: "Welcome to Online Justice :: Uganda Constitution Website and have A good time",
		autoClose: true,
        duration: 5 
                                    });    
                                }                                
        </script> 
<table width="980" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="3">
    <div class="logo"> <img src="images/logo.png" alt="logo" /></div>
    <div class="tagline"><h2> Electronic Ugandan Constitution </h2></div>
    </td>
  </tr>
  <tr>
     <td width="300">
     </td>
    <td align="" width="380">
    <div id="error" style="width:380px;">
    <?php
	if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
		
		foreach($_SESSION['ERRMSG_ARR'] as $msg) {
			echo '<img src="images/ex.png"> - <strong><font color="red">',$msg ,'</font></strong>'; 
		}
		unset($_SESSION['ERRMSG_ARR']);
	}
?>
	
    </div>
    <div id="tabs" style="font-size:12px; ">
    <ul>
		<li><a href="#tabs-1">Login</a></li>
        <li><a href="#tabs-2">Signup</a></li>
        <li><a href="#tabs-3">Forgot Password</a></li>
	</ul>
    <div align="" style="padding-left:50px;" id="tabs-1">
    <form action="auth.php?action=login" method="post" name="login">
    <label style="text-align:left;"><strong>Username</strong></label> <br />
    <input name="loginname" type="text" size="50" id="loginname" title="enter your username" required class="tooltip"/>
    <br />
    <label style="text-align:left;"><strong>Password</strong></label> <br />
    <input name="loginkey" type="password" size="50"  id="loginkey" autocomplete="off" title="enter your password" required class="tooltip"/>
    <br />
    <label for="secCode1"><strong>Captcha text</strong></label>
    <br />
	<img src="securityCode.php" /> <br />
    <label for="secCode1"><strong>Captcha text</strong></label>
    <br />
    <input name="secCode1" type="text"  maxlength="50" size="30" id="secCode1"  autocomplete="off" required title="enter security code" class="tooltip" />
    <br />
    <br />
    <input name="Login" type="submit" value="Login" title="click to login"/>
    </form>
    </div>
    
    <div align="" style="padding-left:50px;" id="tabs-2">
    <form action="saveuser.php" method="post" name="saveuser">
        <label style="text-align:left;"><strong>Select Username</strong></label> <br />
    <input name="username" type="text" size="50" id="username" autocomplete="off" required title="enter your username" class="tooltip"/> <br />
     <span id="availability_status"></span> 
    <br />
    <label style="text-align:left;"><strong>Select Password</strong></label> <br />
    <input name="password" type="password" size="50"  id="password" autocomplete="off" required title="enter your password" class="tooltip"/>
    <br />
    <label style="text-align:left;"><strong>Retype Password</strong></label> <br />
    <input name="password2" type="password" size="50"  id="password" autocomplete="off" required title="confirm your password" class="tooltip"/>
        <br />
    <label style="text-align:left;"><strong>First Name</strong></label> <br />
    <input name="fname" type="text" size="50"  id="fname" autocomplete="off" required title="enter your first name" class="tooltip"/>
         <br />
    <label style="text-align:left;"><strong>Last Name</strong></label> <br />
    <input name="lname" type="text" size="50"  id="lname" autocomplete="off" required title="enter your last name" class="tooltip"/>
             <br />
    <label style="text-align:left;"><strong>E-mail</strong></label> <br />
    <input name="emailcon" type="email" size="50"  id="emailcon" autocomplete="off" required title="enter your email" class="tooltip"/>
    <br />
    <label for="secCode2"><strong>Captcha text</strong></label>
    <br />
	<img src="securityCode.php" /> <br />
    <label for="secCode2"><strong>Captcha text</strong></label>
    <br />
    <input name="secCode2" type="text"  maxlength="50" size="30" id="secCode2"  autocomplete="off" required title="enter security code" class="tooltip"/>
    <br />
    <label for="secqst"> Security Question:</label>
<br /><select name="secqstn1" class="tooltip" id="selectmenu" title="security question" required>
  <option value=""> - select -</option><option value="what is your first pets name?">what is your first pets name?</option> <option value="what is your favorite cousins name?">what is your favorite cousins name?</option> <option value="what did you meet your spouse?">what did you meet your spouse?</option></select> 
<br />
<label for="secans1"> Security Answer:</label> 
<br />
<input name="secans1" type="text"  maxlength="50" size="30"  title="security answer" required id="secans1" autocomplete="off" class="tooltip"/>
    <br />
    <br />
    <input name="Register" type="submit" value="Register" />
    </form>
    </div>
    
    <div align="" style="padding-left:50px;" id="tabs-3">
    <form action="forgot.php" method="post" name="getpwd">
    <label style="text-align:left;"><strong>Username</strong></label> <br />
    <input name="usernameget" type="text" size="50" id="usernameget" required title="enter your username" class="tooltip"/>
    <br />
    <label for="secCodeget"><strong>Captcha text</strong></label>
    <br />
	<img src="securityCode.php" /> <br />
    <label for="secCodeget"><strong>Captcha text</strong></label>
    <br />
    <input name="secCodeget" type="text"  maxlength="50" size="30" id="secCodeget"  autocomplete="off" required title="enter security code" class="tooltip"/>
    <br />
    <label for="secqst"><strong>Security Question</strong></label>
<br /><select name="secqstnget" required id="selectmenu" title="security question" class="tooltip">
  <option value=""> - select -</option><option value="what is your first pets name?">what is your first pets name?</option> <option value="what is your favorite cousins name?">what is your favorite cousins name?</option> <option value="what did you meet your spouse?">what did you meet your spouse?</option></select> 
     <br />
     <label for="secansget"><strong>Security Answer</strong></label>
     <br />
<input name="secansget" type="text"  maxlength="50" size="30"  title="security answer" required id="secansget" autocomplete="off" class="tooltip"/>
    <br />
    <br />
    <input name="Get" type="submit" value="Get" />
    </form>
    </div>
    
    </div>
    </td>
    <td width="300">
    </td>
  </tr>
    <tr>
    <td colspan="3">
    <div>
    &nbsp;
    </div>
    </td>
  </tr>
  <tr>
    <td colspan="3">
    <div class="footer" style="background-image:url(images/footer.png); float:right; width:230px; height:170px; ">
    
    </div>
    </td>
  </tr>
  
</table>
</body>
</html>
