
<?php
session_start();
	//Array to store validation errors
	$errmsg_arr = array();
	
	//Validation error flag
	$errflag = false;
	
	//Connect to mysql server
	include ('dbConnector.php');
	$connector = new DbConnector();
	
	include ('sessions.php');
	
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
	
	//Sanitize the POST values
    $chaptext = clean($_POST['chaptext']);
	$id = clean($_POST['chapno']);
    $id2= $_GET['id2'];

	//$id22=$_GET['id2'];
	//Input Validations
	if($chaptext == '') {
	$errmsg_arr[] = 'chapter title is missing';
	$errflag = true;
	}
	
	if($id2 == '') {
	$errmsg_arr[] = 'chapter number is missing';
	$errflag = true;
	}
	

//If there are input validations, redirect back to the registration form
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: editchap.php?id=$id2");
		exit();
	}
	
	//Create update query

$qry = "update chapters SET title='$chaptext' where capno='$id2'";
	//$query="update user SET profimg='$img', lastedit=NOW() where username='$user'"; 
	//$result = @mysql_query($qry);
	$result = $connector->query($qry);
	//Check whether the query was successful or not
	if($result) {
	$errmsg_arr[] = 'Chapter '. $id2 .'  was edited successfuly';
		$errflag = true;
		if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: editchap.php?id=$id2");
		exit();
	}

			
		header("location: editchap.php?id=$id2");
		exit();
	}else {
		die("Query failed");
		header("location: editchap.php?id=$id2");
		exit();
	}
?>

