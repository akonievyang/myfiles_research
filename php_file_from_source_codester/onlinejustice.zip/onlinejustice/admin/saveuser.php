<?php
	session_start();
	//Include database connection details
	include("dbConnector.php");
	$connector = new DbConnector();
	
	//Array to store validation errors
	$errmsg_arr = array();
	
	//Validation error flag
	$errflag = false;
	
	
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
	
	//Sanitize the POST values
	$fname = clean($_POST['fname']);
	$lname = clean($_POST['lname']);
	$username = clean($_POST['username']);
	$password1 = clean($_POST['password']);
	$cpassword = clean($_POST['password2']);
	$captcha = clean($_POST['secCode2']);
	$emailcon = clean($_POST['emailcon']);
	$secqstn = clean($_POST['secqstn1']);
	$secans = clean($_POST['secans1']);
	//Input Validations
if ($captcha != $_SESSION['securityCode']) {
	//Note: the captcha code is compared case insensitively.
	//if you want case sensitive match, update the check above to
	// strcmp()
		$errmsg_arr[] = 'captcha code is missing or incorrect';
		$errflag = true;
	}
						if($cpassword == '') {
		$errmsg_arr[] = 'password field is missing';
		$errflag = true;
	}
					if($password1 == '') {
		$errmsg_arr[] = 'confirm password field is missing';
		$errflag = true;
	}
					if($lname == '') {
		$errmsg_arr[] = 'last name field is missing';
		$errflag = true;
	}		
			if($fname == '') {
		$errmsg_arr[] = 'first name field is missing';
		$errflag = true;
	}	
			if($username == '') {
		$errmsg_arr[] = 'username field is missing';
		$errflag = true;
	}	
	
		if($emailcon == '') {
		$errmsg_arr[] = 'email field is missing';
		$errflag = true;
	}
	
	if($secans == '') {
		$errmsg_arr[] = 'security answer field is missing';
		$errflag = true;
	}	
		
	if($secqstn == '') {
		$errmsg_arr[] = 'security question field is missing';
		$errflag = true;
	}
		if( strcmp($password1, $cpassword) != 0 ) {
		$errmsg_arr[] = 'Passwords do not match';
		$errflag = true;
	}


//Check for duplicate login ID
	if($username!= '') {
		$qry = "SELECT * FROM user WHERE username='$username'";
		//$result = mysql_query($qry);
		$result = $connector->query($qry);
		if($result) {
			if(mysql_num_rows($result) > 0) {
				$errmsg_arr[] = ' username is already in use, please select another one';
				$errflag = true;
			}
			@mysql_free_result($result);
		}
		else {
			die("Query failed, couldn't verify duplicate username on the database");
		}
	}
//If there are input validations, redirect back to the registration form
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: index.php#tabs-2");
		exit();
	}
	
	//encrypt password 
	$encpass=md5(trim($password1));
	$encsecans=md5(trim($secans));
    
	// user  category
	$cat='admin';
	
	//Create INSERT query
	$qry2 = "INSERT INTO user (username,password,fname,lname,emailcon,secqsn,secans,datein,cat) VALUES ('$username','$encpass','$fname','$lname','$emailcon','$secqstn','$encsecans',NOW(),'$cat')";
	
		//$result = @mysql_query($qry);
	    $result2 = $connector->query($qry2);
	//Check whether the query was successful or not
	if($result2) {
		$errmsg_arr[] = 'User Account for '. $username . ' was created Successfully!';
		$errflag = true;
		if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: index.php#tabs-2");
		exit();
	}

			
		header("location: index.php#tabs-2");
		exit();
	}else {
		die("Query failed, couldnt add the record");
		header("location: index.php#tabs-2");
		exit();
	}
	
	mysql_close();
?>


