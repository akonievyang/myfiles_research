<?php 
include('header.php');
?>
<body>
<br>
<br>
<br>
<div class="container">
<?php
function randomcode() {
					$var = "abcdefghijkmnopqrstuvwxyz0123456789";
					srand((double)microtime()*1000000);
					$i = 0;
					$code = '' ;
					while ($i <= 7) {
						$num = rand() % 33;
						$tmp = substr($var, $num, 1);
						$code = $code . $tmp;
						$i++;
					}
					return $code;
				}
				

?>
<h1>
<?php
echo randomcode();
?>
</h1>
<br>
<a href="index.php" class="btn btn-info">Refresh</a>

</div>
</body>
</html>