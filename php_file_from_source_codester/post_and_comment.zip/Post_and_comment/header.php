<!DOCTYPE html>
<html lang="en">
    <head>

        <title>POST</title>
   
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="screen">
       
       
    </head>
<script src="js/jquery.js" type="text/javascript"></script>
<script src="js/bootstrap.js" type="text/javascript"></script>

<?php include('dbcon.php'); ?>