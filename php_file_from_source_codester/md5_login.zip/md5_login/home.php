<?php 
include('header.php');
?>
<body>
<div class="container">
<br><br>
<div class="alert alert-success">Welcome to Successfully Login</div>
<a href="index.php">Return to Starting Page</a>


</div>
</body>
</html>