<?php 
include('header.php');
?>
<body>
<br><br>

 
	<div class="container">
	    <div class="row-fluid">
    <div class="span6">
	<div class="alert alert-success">Login</div>
	   <form class="form-horizontal" method="POST">
    <div class="control-group">
    <label class="control-label" for="inputEmail">Username</label>
    <div class="controls">
    <input type="text" id="inputEmail" name="username" placeholder="Username" required>
    </div>
    </div>
    <div class="control-group">
    <label class="control-label" for="inputPassword">Password</label>
    <div class="controls">
    <input type="password" name="password" id="inputPassword" placeholder="Password" required>
    </div>
    </div>
    <div class="control-group">
    <div class="controls">
    <button type="submit" name="login" class="btn btn-success">Login</button>
    </div>
	<br>
	<?php
	if (isset($_POST['login'])){
	$username=$_POST['username'];
	$password=md5($_POST['password']);
	
	$login=mysql_query("select * from user where username='$username' and password='$password'")or die(mysql_error());
	$count=mysql_num_rows($login);
	
	if ($count > 0){
	header('location:home.php');
	}else{ ?>
	<div class="alert alert-error">Error login! Please check your username or password</div>
	<?php
	}}
	?>
	
    </div>
    </form>
	</div>
	
	
	
	
	
	
	
	
	
    <div class="span6">
		<div class="alert alert-success">Register User</div>
	<form class="form-horizontal" method="POST">
    <div class="control-group">
    <label class="control-label" for="inputEmail">Username</label>
    <div class="controls">
    <input type="text" id="inputEmail" name="run" placeholder="Username" required>
    </div>
    </div>
    <div class="control-group">
    <label class="control-label" for="inputPassword">Password</label>
    <div class="controls">
    <input type="text" id="inputPassword" name="rp" placeholder="Password" required>
    </div>
    </div>
    <div class="control-group">
    <div class="controls">
    <button type="submit" name="register" class="btn btn-info">Save</button>
    </div>
    </div>
    </form>
	
	    <table class="table table-bordered">
    	<div class="alert alert-success">Data from Database</div>
    <thead>
    <tr>
    <th>Username</th>
    <th>Password</th>
    </tr>
    </thead>
    <tbody>
	<?php 
	$query=mysql_query("select * from user")or die(mysql_error());
	while($row=mysql_fetch_array($query)){
	?>
    <tr>
    <td><?php echo $row['username']; ?></td>
    <td><?php echo $row['password']; ?></td>

    </tr>
	<?php } ?>
    </tbody>
    </table>
	
	</div>
    </div>
	</div>
	
	
	<?php
	if (isset($_POST['register'])){
	$run=$_POST['run'];
	$rp=md5($_POST['rp']);
	
	mysql_query("insert into user (username,password) values('$run','$rp')")or die(mysql_error());
	header('location:index.php');
	
	}
	?>

</body>
</html>