<?php
mysql_select_db('md5_login',mysql_connect('localhost','root',''))or die(mysql_error());

?>