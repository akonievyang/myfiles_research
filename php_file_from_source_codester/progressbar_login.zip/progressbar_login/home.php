<?php include('header.php') ?>  
<body>
<div class="container">
<br>
<br>
<br>
<br>
<br>
<br>
  <div class="span12">

  <h1>Welcome</h1>
   <br>    
   <br>
<a href="index.php">Return to Login</a>   
            
        </div>
		</div>
		</body>