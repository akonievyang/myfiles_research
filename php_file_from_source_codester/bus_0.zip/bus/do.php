<?
$sn=$_GET['serviceno'];
echo "$sn";
?>