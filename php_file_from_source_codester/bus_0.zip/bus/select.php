<?
$serviceno=$_GET['serviceno'];
echo "$serviceno";
?>