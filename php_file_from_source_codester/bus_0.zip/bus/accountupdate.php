<!DOCTYPE html>
<html>
<body>

<?
$db=mysql_connect("127.0.0.1");
mysql_select_db("test",$db);

$query ="select * from registration where un='harsha'";
$result = mysql_query($query);


$fn=mysql_result($result,0,"fn");
$ln=mysql_result($result,0,"un");
$un=mysql_result($result,0,"un");

$sex=mysql_result($result,0,"sex");
$tel=mysql_result($result,0,"tel");
$emailid=mysql_result($result,0,"emailid");

$query1 ="update registration set fn='sriharsha' where un='harsha'";
?>


</script>



<form method="post" action="registrationupdate.php" target="php">
<table border="0" bordercolor="white"  bgcolor="#cccc99" height="200px" width="70%" align="center" >

<tr valign="top" style="height:40px;">
<td colspan="4"><center><h2> Welcome to the sign up page</h2></center></td>
</tr>

<tr>
<td>First Name </td>
<td><input type="text" name="fn" size="15" maxlength="15" value='<? echo "$fn";?>'  /></td>
<td>Last Name</td> 
<td><input type="text" name="ln" size="15" maxlength="15" value='<? echo "$ln";?>'/></td>
</tr>

<tr>
<td>User Name</td>
<td colspan="3"><input type="text" name="usr" size="15" maxlength="15" readonly="readonly" value='<? echo "$un";?>'/></td>
</tr>


<tr style="height:40px;">
<td>Sex</td>
<td colspan="3"><input type="radio" name="sex" value="male" checked>Male<input type="radio" name="sex" value="female"> Female</td>
</tr>



<tr>
<td> Telephone No.</td>
<td> <input type="text" name="phone" size="15" maxlength="13" value='<? echo "$tel";?>'/></td>
</tr>


<td>Alternate Email</td>
<td colspan="3"><input type="text" name="altemail" size="15" maxlength="25" value='<? echo "$emailid";?>'/>  &nbsp; &nbsp; If any, for password recovery</td>
</tr>


<tr>
<tr style="height:40px;">

<td colspan="4"><center><input type="submit"  value="Submit"/></center></td>
</tr>

</form>
</table>

</body>
</html>
