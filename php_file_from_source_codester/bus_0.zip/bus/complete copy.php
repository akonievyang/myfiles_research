<?
$seats=$_GET['c'];
$serviceno=$_GET['serviceno'];
$arr = json_decode($_REQUEST['arr']);
$n=$seats;


$db=mysql_connect("127.0.0.1");
mysql_select_db("test",$db);


$query="select avail from buslist where serviceno=$serviceno";
$result = mysql_query($query);
$a= mysql_result($result, 0);

if($n<=$a && $n!=0)
{
    
for($i=0;$i<$n;$i++)
{
$query ="insert into confirmed values ($serviceno,$arr[$i],1)";
$result = mysql_query($query);
}

$query="update buslist set avail=avail-$n where serviceno=$serviceno"; 
mysql_query($query);

$query="select avail from buslist where serviceno=$serviceno";
$result = mysql_query($query);
$a= mysql_result($result, 0);
echo $a;
if($a<=10 && $a>0)
{
    $query="update buslist set status='Fast Filling' where serviceno=$serviceno"; 
    mysql_query($query);
}
if($a==0)
{
    
    $query="update buslist set status='FULL' where serviceno=$serviceno"; 
    mysql_query($query);
}
if($a>10)
{
    $query="update buslist set status='available' where serviceno=$serviceno"; 
    mysql_query($query);

}

    echo "Successfull Booking";
}
?>


