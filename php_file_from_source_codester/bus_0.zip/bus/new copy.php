<?
session_start();
?>
<html>
<style type="text/css">
h1
{
color:#FFFFFF;
    padding-left:20px;
    padding-top:20px;
}

function printpage()
{
    print(document);
}

</style>
<body>
<?
$serviceno=$_SESSION['service'];
$seats=$_SESSION['seats'];
$arr=$_SESSION['arr'];
$child=$_SESSION['child'];

$n=$seats;


for($i=0;$i<$n;$i++)
{   
    if($i==0)
    {
          $names[$i]=$_POST['0'];
          $ages[$i]=$_POST['6'];
          $sex[$i]=$_POST['12'];
    }
    if($i==1)
    {
          $names[$i]=$_POST['1'];
          $ages[$i]=$_POST['7'];
          $sex[$i]=$_POST['13'];
    }
    if($i==2)
    {
          $names[$i]=$_POST['2'];
          $ages[$i]=$_POST['8'];
          $sex[$i]=$_POST['14'];
    }
    if($i==3)
    {
          $names[$i]=$_POST['3'];
          $ages[$i]=$_POST['9'];
          $sex[$i]=$_POST['15'];
    }
    if($i==4)
    {
          $names[$i]=$_POST['4'];
          $ages[$i]=$_POST['10'];
          $sex[$i]=$_POST['16'];
    }
    if($i==5)
    {
          $names[$i]=$_POST['5'];
          $ages[$i]=$_POST['11'];
          $sex[$i]=$_POST['17'];
    }
    if($sex[$i]==0)
    {
        $sex[$i]="Male";
    }
    if($sex[$i]==1)
    {
        $sex[$i]="Female";
    }

}



$db=mysql_connect("127.0.0.1");
mysql_select_db("test",$db);


$query="select avail from buslist where serviceno=$serviceno";
$result = mysql_query($query);
$a= mysql_result($result, 0);

if($n<=$a && $n!=0)
{
    
    for($i=0;$i<$n;$i++)
    {
        $query ="insert into confirmed values ($serviceno,$arr[$i],1)";
        $result = mysql_query($query);
    }
    
    $query="update buslist set avail=avail-$n where serviceno=$serviceno"; 
    mysql_query($query);
    
    $query="select avail from buslist where serviceno=$serviceno";
    $result = mysql_query($query);
    $a= mysql_result($result, 0);
    echo $a;
    if($a<=10 && $a>0)
    {
        $query="update buslist set status='Fast Filling' where serviceno=$serviceno"; 
        mysql_query($query);
    }
    if($a==0)
    {
        
        $query="update buslist set status='FULL' where serviceno=$serviceno"; 
        mysql_query($query);
    }
    if($a>10)
    {
        $query="update buslist set status='available' where serviceno=$serviceno"; 
        mysql_query($query);
        
    }
    
    //echo "Successfull Booking";
    
    
    $query="select * from buslist where serviceno=$serviceno";
    $result = mysql_query($query);
    
     $src= mysql_result($result, 0,src);
     $dest= mysql_result($result, 0,dest);
     $start= mysql_result($result, 0,start);
     $reach= mysql_result($result, 0,reach);

    
    $query="select fare from buslist where serviceno=$serviceno";
    $result = mysql_query($query);
    $fare= mysql_result($result, 0);
    $cf=$fare*0.6;
    
    $adult=$n-$child;
    $fare = $fare * $adult;
    $fare =$fare+($cf*$child);
    
    echo "<div style='height:15%;background-color:lightblue;'><h1> Confirmation Ticket</h1></div> ";
    echo "<fieldset style='width:75%;margin-left:10%;margin-top:20px'>";
    echo "<table width='70%' align= 'center' style='margin-top:20px' >
    <tr>
    <td>Service no</td>
    <td>$serviceno</td>
    </tr>
    
    <tr>
    <td colspan='4'>&nbsp;
    </tr>
    
    <tr>
    <td>From Place : </td>
    <td>$src</td>
    
    <td>To Place : </td>
    <td>$dest</td>
    </tr>
    
    <tr>
    <td colspan='4'>&nbsp;
    </tr>
    
    <tr>
    <td>Departure</td>
    <td>$start</td>
    
    <td>Reach</td>
    <td>$reach</td>
    </tr>
    
    </table>";
    
    
    echo"<fieldset style='width:60%;margin-left:15%;margin-top:20px'> 
         <table  align='center' style='padding:0;'>
    <tr>
     <td style='width:10%'>Sex </td>
    <td style='width:30%'> Name </td>
    <td style='width:20%'> Age  </td>
    <td style='width:40%'> Seat no.</td>
    </tr>";

    
    for($i=0;$i<$n;$i++)
    {
     echo "
     <tr>
     <td style='width:30%'> $sex[$i]</td>   
     <td style='width:30%'> $names[$i]</td>
     <td style='width:30%'> $ages[$i]</td>   
     <td style='width:30%'> $arr[$i] </td>
     </tr>";
    }
    
    
    echo"    
    </table>
    </fieldset>";
    echo "<div style='padding-left:15%;margin-top:20px;'> Fare : "." $fare"."<div>";
    echo"
    </fieldset>";

    
}
?>

<?
echo "<br><br>";
echo "<center><form><input type='button' value='Click me!' onclick='printpage()' /></form></center>";

?>

</body>
</html>














