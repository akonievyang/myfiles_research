<?

session_start();
$user_check=$_SESSION['login_user'];



$filename=$_FILES["photo"]["tmp_name"];
$fileerror=$_FILES["photo"]["error"];
$filetype1=basename($_FILES["photo"]["name"]);
$filetype2=$_FILES["photo"]["size"];
echo "$filename";
echo "<br/>";
echo "$fileerror";
echo "<br/>";
echo "$filetype2";
echo "<br/>";
if($_FILES["photo"]["size"]>10000000)
{
    echo "File too big";
    exit;
}
echo"Ok";

  if( move_uploaded_file( $filename,"photos/".basename($_FILES["photo"]["name"])))
{
   
    
    
    echo "success"."<br/>";
    echo "Thanks for uploading your photo"."<br/>";
    echo "<p><img src='photos/$filetype1'/></p>"; 
   
    $db=mysql_connect("127.0.0.1");
    mysql_select_db("test",$db);
    $query="insert into images values('$filetype1','$user_check')";
    mysql_query($query);
}
else
{
    echo "failed";
}

?>