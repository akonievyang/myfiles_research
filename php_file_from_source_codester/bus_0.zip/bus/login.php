<?
$un = $_POST['user'];
$pd = $_POST['pwd'];


$link="<a href='form.html'> Click here for login </a>";
$link1="<a href='present.html'> Click here for Signup </a>";

if($un ==''|| $pd =='')//checking not null
{
    echo "Please enter all the details"."<br>";
    echo "$link";
    exit;
}



$db=mysql_connect("127.0.0.1");
mysql_select_db("test",$db);

$query ="select * from registration where un='$un' and pd = '$pd'";
$result = mysql_query($query);

if(mysql_num_rows($result)==1)//to check
{
    
    $url="bussearch.html";
    echo "<META HTTP-EQUIV=Refresh CONTENT='1; URL=".$url."'>";
}

else
{ 
    $query ="select * from registration where un='$un'";
    $result = mysql_query($query);
    if(mysql_num_rows($result)==1)
    {
        echo "In correct password"."<br>";
        echo "$link";
    }
    else
    {
        echo "No such user name exists"."<br>";
        echo "Signup here"."<br>";
        echo "$link1";
        
    }
    



}

?>






















