<?
session_start();
?>

<html>

<head>
    <title>Bus Search</title>
</head>

<style>

td
{
text-align:center;
}

tr
{
height:30px;
}




</style>



<body>

<?
$way = $_GET['way'];
$src= $_GET['from'];
$dest = $_GET['to'];
$adult= $_GET['adult'];
$child= $_GET['child'];
$class = $_GET['bustype'];
$departure = $_GET['departure'];
$return = $_GET['return'];

$_SESSION['child']=$child;
$total=$adult+$child;



$link="<a href='main.html' target='_self'> back </a>";

if($src =='0')
{
    echo "<center>Please enter all the details</center>"."<br>";
    echo "$link";
    exit;
}


$db=mysql_connect("127.0.0.1");
mysql_select_db("test",$db);

    $query="SELECT DATEDIFF('$departure',curdate())<=15 from dual";
    $result = mysql_query($query);
    
    $a= mysql_result($result, 0);
echo "$a"."<br>";
$query="SELECT DATEDIFF('$departure',curdate())>0 from dual";
$result = mysql_query($query);

$b= mysql_result($result, 0);
echo "$b"."<br>";
    if($a==0 || $b==0)
    {
        if($a==0)
        {
            echo "List is shown only 15 days before";
        }
        else
        {
            echo "Not a valid date";
        }
        echo "<br>"."$link";
        exit;
    }
    
    $query ="select * from buslist where src='$src' and dest ='$dest'";
    $result = mysql_query($query);
    
    if(mysql_num_rows($result)==0)//to check
    {
        echo "No Search Available";
        exit;
        
    }
    
?>
      
        <table bgcolor="#AAAAAA" width="75%" cellpadding="1" cellspacing="1">
       <tr>
            <td> Service No.</td>
            <td> Source</td>
            <td> Destination</td>
            <td> Departure</td>
            <td> Reach</td>
            <td> Seats Avail</td>
            <td> Status</td>
            <td> Fare &nbsp;&nbsp;&nbsp;&nbsp; </td>
        </tr>




        <?
        for ($i=0; $i<mysql_num_rows($result);$i++)
        {
            $serviceno=mysql_result($result, $i,"serviceno");
            $src=mysql_result($result, $i,"src");
            $dest=mysql_result($result, $i,"dest");
            $start=mysql_result($result, $i,"start");
            $reach=mysql_result($result, $i,"reach");
            $avail=mysql_result($result, $i,"avail");
            $status=mysql_result($result, $i,"status");
            $fare=mysql_result($result, $i,"fare");
            
            if($i%2)
            {
              $color=" #EEEEEE";  
            }
            else
            {
                $color="#EOEOEO";
            }
            
            echo"
            <tr bgcolor='$color'> 
               <td>". "$serviceno". "</td>".
               "<td>". "$src".   "</td>".
               "<td>". "$dest".  "</td>".
               "<td>". "$start". "</td>".
               "<td>". "$reach". "</td>".
               "<td>". "$avail". "</td>".
               "<td>". "$status"."</td>".
               "<td>". "$fare".  "</td>".
               "<td>". "<a href='layout.php?serviceno=$serviceno&total=$total'>Book </a>".  "</td>"."</tr>";
            
        }
?>

        </table>
        
</body>
</html>

        
        
        
        
  
       
        

        

    
    
























