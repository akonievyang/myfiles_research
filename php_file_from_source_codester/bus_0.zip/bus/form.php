<?
$db=mysql_connect("127.0.0.1");
mysql_select_db("test",$db);
session_start();
if($_SERVER["REQUEST_METHOD"]== "POST")
   {
       
       $un = $_POST['user'];
       $pd = $_POST['pwd'];
       
       $query ="select * from registration where un='$un' and pd = '$pd'";
       $result = mysql_query($query);
       
       $row=mysql_fetch_array($result);
       $active=$row['active'];
       
       $count= mysql_num_rows($result);
       if($un=="" || $pd=="")
       {
           $error="";
           echo "<script>\n";
           echo "alert('Please enter all details')";
           echo "</script>";
           $error="";
       }
       
       
       
       else if($count==1)
       {
           session_register("un");
           $_SESSION['login_user']=$un;

           header("location:main.php");
           
       }
       else
       {
           $error="Invalid username or password";
       }
   }


?>

<!DOCTYPE html>
<html>

<head>
<title> Login Page</title>
</head>


<body  link="yellow" vlink="lime" alink="red">



<form action="" name="Login" method="post">
<fieldset style="width:230px;height:150px">
<legend> Login Here ...</legend>

<table >
    <tr> &nbsp;</tr>
    
    <tr>
    <td>User Name</td>
<td><input type="text" name="user" size="15" maxlength="15" value='<? echo "$un";?>'/></td>
    </tr>

    <tr>
    <td>Password</td>
    <td><input type="password" name="pwd" size="15" maxlength="15"/></td>
    </tr>

    <tr>
    <td><input type="reset" name="reset"value="&nbsp;&nbsp;Reset&nbsp;&nbsp;"/></td>
    <td><input type="submit" name="submit" value="&nbsp;&nbsp;Login&nbsp;&nbsp;"/> <a href="signup.html">New User..?</a></td>
    </tr>

    <tr>
    <td colspan= "2">  <? echo"$error";?></td>    </tr>

</table>

</fieldset>
</form>
</body>
</html>




















</html>
