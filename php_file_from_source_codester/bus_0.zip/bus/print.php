<html>
<body>

<?

$name=$_GET['name'];
echo "<center><img src='photos/$name' height='70%' width='40%'></img></center>";
echo "<br><br>";
echo "<center><form><input type='button' value='Click me!' onclick='printpage()' /></form></center>";

?>

</body>

<script>
function printpage()
{
    print(document)
}
</script>

</html>