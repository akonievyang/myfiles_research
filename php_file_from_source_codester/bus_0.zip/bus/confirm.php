<?
session_start();
?>
<html>
<body>

<table cellpadding="1" cellspacing="1" >
<tr   bgcolor="#AAAAAA"> 
<td align="center"> Sex </td>
<td align="center"> Name </td>
<td align="center"> Age </td>
</tr>


<?

$seats=$_GET['c'];
$serviceno=$_GET['serviceno'];
$arr = json_decode($_REQUEST['arr']);
$n=$seats;


$_SESSION['service']=$serviceno;
$_SESSION['seats']=$n;
$_SESSION['arr']=$arr;


?>

<script type="text/javascript">

var n=0;
var j= new Array();

n = <? echo "$n";?>;
var serviceno = <? echo "$serviceno";?>;
</script>

<?
for ($i=0; $i<$n ;$i++)
{
    $p=$arr[$i];
    echo "<script>\n";
    echo "j.push($p)\n";
    echo "</script>";
}
?>

<form action="new.php" method="post">
<?
for($i=0;$i<$n;$i++)
{
    
    if($i%2)
    {
        $color=" #EEEEEE";  
    }
    else
    {
        $color="#EOEOEO";
    }
    
    $a=$i+6;
    $s=$i+12;
    echo "<tr bgcolor='$color'>
    
    <td width='90px' align='center'>
    <select name='$s'>
    <option value='0'>Male</option>
    <option value='1 '>Female</option>
    </select>
    </td>
    
    <td width='170px' align='center' ><input type ='text' name='$i'</input> </td>
    <td width='60px' align='center'>  <input type ='text' name='$a' size='5' maxlength='3' </input> </td>
    
    </tr>";
    
    
    
}
echo "You have selected the seats:  ";

for($i=0;$i<$n;$i++)
{
echo "$arr[$i]"."&nbsp;&nbsp;&nbsp;&nbsp;";
}
echo "<br><br>";

?>


<tr>
<td>&nbsp;  </td>
</tr>



<tr>
<td></td>
<td align="center">  <input type="submit" value="submit"></input>  </td>



</table>
</form>

</br>
</br>




</body>
</html>








