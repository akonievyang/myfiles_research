<?
  $arr = json_decode($_REQUEST['arr']);

echo "$arr[0]";
?>
