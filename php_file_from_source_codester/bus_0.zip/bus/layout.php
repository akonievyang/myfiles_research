<html>
<head>
</head>
<?
$total=$_GET['total'];
$serviceno=$_GET['serviceno'];

?>

<script type="text/javascript">
var count=0; 
var max=3;
var n=0;
var arr= new Array();

max = <? echo "$total";?>;
var serviceno = <? echo "$serviceno";?>;
var a=3;

function selected()
{
    var j=0;
    for(var i=1;i<=41;i++)
    {
        if(document.getElementById(i).src == 'http://localhost/bus/2.png')
        {
            arr[j]=i;
            j++;
        }
    }
    
    var urlstring="confirm.php?c="+count+"&serviceno="+serviceno+"&arr="+JSON.stringify(arr);
    window.location = urlstring;
    
}


function displaymessage()
{
    alert("You cannot book more seats");
}


function change(id)
{    
    
    if(document.getElementById(id).src == 'http://localhost/bus/1.png')// please give the paths of the .png images as according to your project..
    {
        
        if(count==max)
        {
            displaymessage();
        }
        else
        { 
            document.getElementById(id).src="2.png"; 
            count++;
        }
    }
    else if(document.getElementById(id).src== 'http://localhost/bus/2.png')
    {
        document.getElementById(id).src="1.png";
        count--;
    }
    else{
      
        
    }
    
}



</script>



<body>
<div style="width:30%;float:left;">

<div id="b1" title="val">
<img border="0" alt="bus" src="1.png" id="1" 
onclick="change(1)"  />
<img border="0" alt="bus" src="1.png" id="2"
onclick="change(2)"  />
<img border="0" alt="bus" src="1.png" id="3"
onclick="change(3)"  />
<img border="0" alt="bus" src="1.png" id="4"
onclick="change(4)"  />
<img border="0" alt="bus" src="1.png" id="5"
onclick="change(5)"  />
<img border="0" alt="bus" src="1.png" id="6"
onclick="change(6)"  />
<img border="0" alt="bus" src="1.png" id="7"
onclick="change(7)"  />
<img border="0" alt="bus" src="1.png" id="8"
onclick="change(8)"  />
<img border="0" alt="bus" src="1.png" id="9"
onclick="change(9)"  />
<img border="0" alt="bus" src="1.png" id="10"
onclick="change(10)"  />
</div>

<div >
<img border="0" alt="bus" src="1.png" id="11"
onclick="change(11)"  />
<img border="0" alt="bus" src="1.png" id="12"
onclick="change(12)"  />
<img border="0" alt="bus" src="1.png" id="13"
onclick="change(13)"  />
<img border="0" alt="bus" src="1.png" id="14"
onclick="change(14)"  />
<img border="0" alt="bus" src="1.png" id="15"
onclick="change(15)"  />
<img border="0" alt="bus" src="1.png" id="16"
onclick="change(16)"  />
<img border="0" alt="bus" src="1.png" id="17"
onclick="change(17)"  />
<img border="0" alt="bus" src="1.png" id="18"
onclick="change(18)"  />
<img border="0" alt="bus" src="1.png" id="19"
onclick="change(19)"  />
<img border="0" alt="bus" src="1.png" id="20"
onclick="change(20)"  />
</div>

<div height="50%">
<pre style="padding-left:215px"><img border="0" alt="bus" src="1.png" id="21"
onclick="change(21)"  /></pre>
</div>

<div >
<img border="0" alt="bus" src="1.png" id="22"  onclick="change(22)"/>
<img border="0" alt="bus" src="1.png" id="23" onclick="change(23)"/>
<img border="0" alt="bus" src="1.png" id="24" onclick="change(24)"/>
<img border="0" alt="bus" src="1.png" id="25" onclick="change(25)"/>
<img border="0" alt="bus" src="1.png" id="26"  onclick="change(26)"/>
<img border="0" alt="bus" src="1.png" id="27"  onclick="change(27)"/>
<img border="0" alt="bus" src="1.png" id="28"  onclick="change(28)"/>
<img border="0" alt="bus" src="1.png" id="29"  onclick="change(29)"/>
<img border="0" alt="bus" src="1.png" id="30"  onclick="change(30)"/>
<img border="0" alt="bus" src="1.png" id="31"  onclick="change(31)"/>
</div>

<div >
<img border="0" alt="bus" src="1.png" id="32"  onclick="change(32)"/>
<img border="0" alt="bus" src="1.png" id="33"  onclick="change(33)"/>
<img border="0" alt="bus" src="1.png" id="34"  onclick="change(34)"/>
<img border="0" alt="bus" src="1.png" id="35"  onclick="change(35)"/>
<img border="0" alt="bus" src="1.png" id="36"  onclick="change(36)"/>
<img border="0" alt="bus" src="1.png" id="37"  onclick="change(37)"/>
<img border="0" alt="bus" src="1.png" id="38"  onclick="change(38)"/>
<img border="0" alt="bus" src="1.png" id="39"  onclick="change(39)"/>
<img border="0" alt="bus" src="1.png" id="40"  onclick="change(40)"/>
<img border="0" alt="bus" src="1.png" id="41"  onclick="change(41)"/>
</div>





<script>
var j= new Array();
</script>
<?

$sn=$_GET['serviceno'];

$db=mysql_connect("127.0.0.1");
mysql_select_db("test",$db);
$query ="select * from confirmed where serviceno=$sn";
$result = mysql_query($query);
$n = mysql_num_rows($result);
$seats=array();
for ($i=0; $i<$n ;$i++)
{
    $p=$seats[$i]=mysql_result($result, $i,"seat");
    echo "<script>\n";
    echo "n++\n";
    echo "j.push($p)\n";
    echo "</script>";
}

?>

<script>
for (var i=0;i<n;i++)
{
    document.getElementById(j[i]).src="3.png";
}
</script>
 

<br/>
<input type="submit" value="&nbsp;&nbsp;&nbsp;Proceed&nbsp;&nbsp;&nbsp;" onclick="selected()";></input>

</div>

<div  style="float:left;padding-top:20px;">

<table rules="none">

<tr>

<td><img border="0"  src="3.png"  > </img><td>
<td>&nbsp;&nbsp;Reserved</td>
</tr>

<tr>

<td><img border="0"  src="2.png"  > </img><td>
<td>&nbsp;&nbsp;Selected</td>
</tr>

<tr>

<td><img border="0"  src="1.png"  > </img><td>
<td>&nbsp;&nbsp;Available</td>
</tr>


</div>

</body>
</html>