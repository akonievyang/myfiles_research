<!DOCTYPE html>
<html>
<body>

<?
$fn = $_POST['fn'];
$ln = $_POST['ln'];
$un = $_POST['usr'];

$sex = $_POST['sex'];
$tel =$_POST['phone'];
$emailid = $_POST['altemail'];


$db=mysql_connect("127.0.0.1");
mysql_select_db("test",$db);

$query ="update registration set fn='$fn', ln='$ln', sex='$sex', tel='$tel', emailid='$emailid' where un='$un'";
$result = mysql_query($query);
if($result!=0)
{
    echo "Account successfully Updated";
}

?>






</body>
</html>
