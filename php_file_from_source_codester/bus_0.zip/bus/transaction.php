<?
$seats=$_GET['c'];
$serviceno=$_GET['serviceno'];
$arr = json_decode($_REQUEST['arr']);
$n=$seats;
?>

<html>
<body>

<script>
var j= new Array();
</script>

<?
for ($i=0; $i<$n ;$i++)
{
    $p=$arr[$i];
    echo "<script>\n";
    echo "j.push($p)\n";
    echo "</script>";
}
?>

<script type="text/javascript">
var n= <? echo "$n";?>;
var serviceno = <? echo "$serviceno";?>;

function nextpage()
{
    if(document.getElementById(cvv).length !=0)
    {
        alert("please enter valid details");
        
    }
    else
    {
    var urlstring="complete.php?c="+n+"&serviceno="+serviceno+"&arr="+JSON.stringify(j);
    window.location = urlstring;  
    }
    
    
}
</script>

<table cellpadding="4">

<tr> 
<td colspan="2" align="center"> <h2>Transaction gateway</h2></td>
</tr>

<tr> 
<td><input type="radio" name="card">&nbsp;Debit card </input>&nbsp;&nbsp;</td>
<td><input type="radio" name="card">&nbsp;Credit card </input></td>
</tr>

<tr>
<td> Card Number </td>
<td><input type="text" size="4" maxlength="4"></input>&nbsp;&nbsp;<input type="text" size="4" maxlength="4"></input>&nbsp;&nbsp;<input type="text" size="4" maxlength="4"></input>&nbsp;&nbsp;<input type="text" size="4" maxlength="4"></input>
</td>
</tr>


<tr>
<td> CVV </td>
<td><input type="text" size="3"  maxlength="3" id="cvv" name="qw"></input></td>
</tr>

<tr>
<td> Name on the card </td>
<td><input type="text"></input></td>
</tr>

</table>

<input type="submit" onclick="nextpage()"></input>

</body>
</html>