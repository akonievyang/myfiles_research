<html>
<body>

<table cellpadding="1" cellspacing="1" >
<tr   bgcolor="#AAAAAA"> 
<td align="center"> Sex </td>
<td align="center"> Name </td>
<td align="center"> Age </td>
</tr>


<?
$seats=$_GET['c'];
$serviceno=$_GET['serviceno'];
$arr = json_decode($_REQUEST['arr']);
$n=$seats;




?>

<script type="text/javascript">

var n=0;
var j= new Array();

n = <? echo "$n";?>;
var serviceno = <? echo "$serviceno";?>;
</script>

<?
for ($i=0; $i<$n ;$i++)
{
    $p=$arr[$i];
    echo "<script>\n";
    echo "j.push($p)\n";
    echo "</script>";
}
?>

<script type="text/javascript">
function nextpage()
{
    
    var urlstring="complete.php?c="+n+"&serviceno="+serviceno+"&arr="+JSON.stringify(j);
    window.location = urlstring;   
    
    
}
</script>


<?
for($i=0;$i<$n;$i++)
{
    
    if($i%2)
    {
        $color=" #EEEEEE";  
    }
    else
    {
        $color="#EOEOEO";
    }
    
    echo "<tr bgcolor='$color'>
    
    <td width='90px' align='center'><select>
    <option>Male</option>
    <option>Female</option>
    </select>
    </td>
    
    <td width='170px' align='center' ><input type ='text'</input> </td>
    <td width='60px' align='center'><input type ='text' size='5' maxlength='3'</input> </td>
    
    
    
    </tr>";
    
    
    
}
echo "You have selected the seats:  ";

for($i=0;$i<$n;$i++)
{
echo "$arr[$i]"."&nbsp;&nbsp;&nbsp;&nbsp;";
}
echo "<br><br>";

?>


<tr>
<td>&nbsp;  </td>
</tr>



<tr>
<td></td>
<td align="center">  <input type="submit" onclick="nextpage()"></input>  </td>



</table>

</br>
</br>




</body>
</html>








