
<?

if($_SERVER["REQUEST_METHOD"]== "POST")
{
    $way = $_POST['way'];
    $src= $_POST['from'];
    $dest = $_POST['to'];
    $adult= $_POST['adult'];
    $child= $_POST['child'];
    $class = $_POST['bustype'];
    $departure = $_POST['departure'];
    $return = $_POST['return'];
  
    
    //$query ="select * from registration where un='$un' and pd = '$pd'";
    //$result = mysql_query($query);
    
    //$row=mysql_fetch_array($result);
    //$active=$row['active'];
    
    //$count= mysql_num_rows($result);
    
    $total= $adult+$child;
    
    if($src=="0" || $dest=="0"||$total=="0" || $departure=="")
    {
        $error="";
        echo "<script>\n";
        echo "alert('Please enter all details')";
        echo "</script>";
        $error="";
    }
    
    
    
    else
    {

        echo "<script>\n";
        echo "window.open('bussearch.php?way=$way&from=$src&to=$dest&adult=$adult&child=$child&bustype=$class&departure=$departure&return=$return','_parent')\n";
        echo "</script>";
    }
   
}
?>

<html>
<head>

<style type="text/css">
h3
{
    color:#FFFFFF;
    padding-top:20px;
}
</style>
    
    

</head>

<body>

  <div style="background-color:red; height:20%;  text-indent:80%;"><h3><?  echo " Welcome "." $user_check "."..";?></h3></div>

  <div style="height:65%;"> 
  <form action="" method="post" target="_self">
  <table height="50%" width="30%" border="0" align="right" style="padding-top:-5pt;">
<tr>
    <td colspan="4"> <h3> Book Tickets Now!</h3> </td>
</tr>

<tr>
    <td  colspan="4"><input type="radio" name="way" value="2" onclick="document.getElementById('datepick2').disabled=false"> Two Way </input>
    <input type="radio" name="way" checked value="1" onclick="document.getElementById('datepick2').disabled=true"> One Way </input> </td>
</tr> 
<tr>
    <td colspan="2">From: </td>
    <td colspan="2">
    <select name="from" width="20" value='<? echo "$src";?>'>
    <option value="0">Select</option>
    <option value="bangalore">bangalore</option>
    <option value="hyderabad">hyderabad</option>
    <option value="mumbai">mumbai</option>
    <option value="udupi">udupi</option>
    <option value="madurai">madurai</option>
    <option value="kurnool">kurnool</option>
    </select>
    </td>
</tr>


<tr>
    <td colspan="2">To: </td>
    <td colspan="2">
    <select name ="to">
    <option value="0">Select</option>
    <option value="bangalore">bangalore</option>
    <option value="hyderabad">hyderabad</option>
    <option value="mumbai">mumbai</option>
    <option value="udupi">udupi</option>
    <option value="madurai">madurai</option>
    <option value="kurnool">kurnool</option>
    </select>
    </td>
</tr>

<tr>
    <td colspan="2"> No.Of Passangers:</td>
    
    <td>
    <select name ="adult">
    <option value="0">Adult</option>
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    <option value="6">6</option>
    </select>
    </td>
    
    <td>
    <select name ="child">
    <option value="0">Child</option>
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    </select>
    </td>
    
    
</tr>


<tr>
<td colspan="2"> Departure</td>
<td colspan="2"><input id="datepick1" size="10" name="departure" value='<? echo "$departure";?>'/>
</tr>

<tr>
<td colspan="2"> Return</td>
<td colspan="2"><input id="datepick2" size="10"  name="return" disabled/>
</tr>





<tr>
    <td colspan="2">Bus Type: </td>
    <td colspan="2">
    <select name="bustype">
    <option>Super Luxury</option>
    <option>Garuda A/C</option>
    <option>Vennela</option>
    <option>Express</option>
    </select>
    </td>
</tr>

<tr>
    <td colspan="2">Concession: </td>
    <td colspan="2">
    <select name="concession">
    <option value="0">General Booking</option>
    <option value="1">Cat Card</option>
    </select>
    </td>
</tr>

<tr>

<td colspan ="4" style="padding-top:10pt;padding-left:70pt"><input type="image" type="submit" src="avail.png"></input></td>
</tr>


</table>
</form>
</div>
<div style="background-color:green; height:100px;"></div>


</body>
		
		<style type="text/css">
			.calendar {
				font-family: 'Trebuchet MS', Tahoma, Verdana, Arial, sans-serif;
				font-size: 0.9em;
				background-color: #EEE;
				color: #333;
				border: 1px solid #DDD;
				-moz-border-radius: 4px;
				-webkit-border-radius: 4px;
				border-radius: 4px;
				padding: 0.2em;
				width: 10em;
			}
			
			.calendar .months {
				background-color: #F6AF3A;
				border: 1px solid #E78F08;
				-moz-border-radius: 4px;
				-webkit-border-radius: 4px;
				border-radius: 4px;
				color: #FFF;
				padding: 0.2em;
				text-align: center;
			}
			
			.calendar .prev-month,
			.calendar .next-month {
				padding: 0;
			}
			
			.calendar .prev-month {
				float: left;
			}
			
			.calendar .next-month {
				float: right;
			}
			
			.calendar .current-month {
				margin: 0 auto;
			}
			
			.calendar .months .prev-month,
			.calendar .months .next-month {
				color: #FFF;
				text-decoration: none;
				padding: 0 0.4em;
				-moz-border-radius: 4px;
				-webkit-border-radius: 4px;
				border-radius: 4px;
				cursor: pointer;
			}
			
			.calendar .months .prev-month:hover,
			.calendar .months .next-month:hover {
				background-color: #FDF5CE;
				color: #C77405;
			}
			
			.calendar table {
				border-collapse: collapse;
				padding: 0;
				font-size: 0.8em;
				width: 70%;
			}
			
			.calendar th {
				text-align: center;
			}
			
			.calendar td {
				text-align: right;
				padding: 1px;
				width: 14.3%;
			}
			
			.calendar td span {
				display: block;
				color: #1C94C4;
				background-color: #F6F6F6;
				border: 1px solid #CCC;
				text-decoration: none;
				padding: 0.2em;
				cursor: pointer;
			}
			
			.calendar td span:hover {
				color: #C77405;
				background-color: #FDF5CE;
				border: 1px solid #FBCB09;
			}
			
			.calendar td.today span {
				background-color: #FFF0A5;
				border: 1px solid #FED22F;
				color: #363636;
			}
		</style>


<script type="text/javascript" src="datepickr.js"></script>
		<script type="text/javascript">
						
			new datepickr('datepick1', {
				'dateFormat': '20y-m-d'
			});
            
            new datepickr('datepick2', {
				'dateFormat': '20y-m-d'
			});
			
			
		</script>


</html>
