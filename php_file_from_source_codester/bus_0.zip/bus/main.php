<?
session_start();
$user_check=$_SESSION['login_user'];

if(!isset($user_check))
{
    header("Location:form.php?error=not logged");
}
?>


<html>

<frameset  rows="15%,*"  border="3" bordercolor="red">
<frame src="no.html" scrolling="no"/>
<frame  src="bussearch1.php"name="bottom" scrolling="no"/>
/Library/WebServer/Documents/bus/main.php
<noframes> sorry lower version </noframes>
</frameset>
2 frame are created not a continer tag 
</html>