-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 06, 2013 at 01:33 PM
-- Server version: 5.5.25
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `buslist`
--

CREATE TABLE `buslist` (
  `serviceno` int(11) NOT NULL,
  `src` varchar(40) NOT NULL,
  `dest` varchar(40) NOT NULL,
  `start` time NOT NULL,
  `reach` time NOT NULL,
  `avail` int(3) NOT NULL,
  `status` varchar(30) NOT NULL,
  `fare` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buslist`
--

INSERT INTO `buslist` (`serviceno`, `src`, `dest`, `start`, `reach`, `avail`, `status`, `fare`) VALUES
(6629, 'bangalore', 'kurnool', '20:30:30', '05:00:00', 41, 'available', 400),
(6622, 'bangalore', 'hyderabad', '20:30:00', '05:00:00', 41, 'available', 600),
(6621, 'bangalore', 'kurnool', '20:30:00', '05:00:00', 41, 'available', 440),
(6628, 'bangalore', 'kurnool', '20:30:30', '06:00:00', 41, 'available', 440),
(6627, 'bangalore', 'kurnool', '20:30:00', '06:00:00', 41, 'available', 440);

-- --------------------------------------------------------

--
-- Table structure for table `confirmed`
--

CREATE TABLE `confirmed` (
  `serviceno` int(11) NOT NULL,
  `seat` int(11) NOT NULL,
  `flag` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `confirmed`
--

INSERT INTO `confirmed` (`serviceno`, `seat`, `flag`) VALUES
(6629, 1, 1),
(6629, 22, 1),
(6629, 31, 1),
(6628, 2, 1),
(6628, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `name` varchar(50) NOT NULL,
  `un` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`name`, `un`) VALUES
('images.jpeg', 'harsha'),
('1.png', 'harsha');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `fn` varchar(15) NOT NULL,
  `ln` varchar(15) NOT NULL,
  `un` varchar(15) NOT NULL,
  `pd` varchar(10) NOT NULL,
  `cpd` varchar(10) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `emailid` varchar(25) NOT NULL,
  `prof` varchar(40) NOT NULL,
  `question` int(11) NOT NULL,
  `ans` varchar(40) NOT NULL,
  PRIMARY KEY (`un`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`fn`, `ln`, `un`, `pd`, `cpd`, `sex`, `tel`, `emailid`, `prof`, `question`, `ans`) VALUES
('lagisetty', 'harsha', 'harsha', 'sri', 'sri', 'male', '8971737286', 'sriharsha.lagisetty@gmail', 'hi', 2, 'harsha');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
