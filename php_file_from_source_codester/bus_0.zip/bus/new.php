<?
session_start();
require_once 'class.xhttp.php';
?>
<html>
<head>
<meta name="txtweb-appkey" content="713a2c3b-fb57-4f91-a6b1-3328bb3a30b0"/>
</head>
</head>
<style type="text/css">
h1
{
color:#FFFFFF;
    padding-left:20px;
    padding-top:20px;
}

function printpage()
{
    print(document);
}

</style>
<body>
<?
$serviceno=$_SESSION['service'];
$seats=$_SESSION['seats'];
$arr=$_SESSION['arr'];
$child=$_SESSION['child'];

$n=$seats;


for($i=0;$i<$n;$i++)
{   
    if($i==0)
    {
          $names[$i]=$_POST['0'];
          $ages[$i]=$_POST['6'];
          $sex[$i]=$_POST['12'];
    }
    if($i==1)
    {
          $names[$i]=$_POST['1'];
          $ages[$i]=$_POST['7'];
          $sex[$i]=$_POST['13'];
    }
    if($i==2)
    {
          $names[$i]=$_POST['2'];
          $ages[$i]=$_POST['8'];
          $sex[$i]=$_POST['14'];
    }
    if($i==3)
    {
          $names[$i]=$_POST['3'];
          $ages[$i]=$_POST['9'];
          $sex[$i]=$_POST['15'];
    }
    if($i==4)
    {
          $names[$i]=$_POST['4'];
          $ages[$i]=$_POST['10'];
          $sex[$i]=$_POST['16'];
    }
    if($i==5)
    {
          $names[$i]=$_POST['5'];
          $ages[$i]=$_POST['11'];
          $sex[$i]=$_POST['17'];
    }
    if($sex[$i]==0)
    {
        $sex[$i]="Male";
    }
    if($sex[$i]==1)
    {
        $sex[$i]="Female";
    }

}



$db=mysql_connect("127.0.0.1");
mysql_select_db("test",$db);


$query="select avail from buslist where serviceno=$serviceno";
$result = mysql_query($query);
$a= mysql_result($result, 0);

if($n<=$a && $n!=0)
{
    
    for($i=0;$i<$n;$i++)
    {
        $query ="insert into confirmed values ($serviceno,$arr[$i],1)";
        $result = mysql_query($query);
    }
    
    $query="update buslist set avail=avail-$n where serviceno=$serviceno"; 
    mysql_query($query);
    
    $query="select avail from buslist where serviceno=$serviceno";
    $result = mysql_query($query);
    $a= mysql_result($result, 0);
    echo $a;
    if($a<=10 && $a>0)
    {
        $query="update buslist set status='Fast Filling' where serviceno=$serviceno"; 
        mysql_query($query);
    }
    if($a==0)
    {
        
        $query="update buslist set status='FULL' where serviceno=$serviceno"; 
        mysql_query($query);
    }
    if($a>10)
    {
        $query="update buslist set status='available' where serviceno=$serviceno"; 
        mysql_query($query);
        
    }
    
    //echo "Successfull Booking";
    
    
    $query="select * from buslist where serviceno=$serviceno";
    $result = mysql_query($query);
    
     $src= mysql_result($result, 0,src);
     $dest= mysql_result($result, 0,dest);
     $start= mysql_result($result, 0,start);
     $reach= mysql_result($result, 0,reach);

    
    $query="select fare from buslist where serviceno=$serviceno";
    $result = mysql_query($query);
    $fare= mysql_result($result, 0);
    $cf=$fare*0.6;
    
    $adult=$n-$child;
    $fare = $fare * $adult;
    $fare =$fare+($cf*$child);
    
    echo "<div style='height:15%;background-color:lightblue;'><h1> Confirmation Ticket</h1></div> ";
    echo "<fieldset style='width:75%;margin-left:10%;margin-top:20px'>";
    echo "<table width='70%' align= 'center' style='margin-top:20px' >
    <tr>
    <td>Service no</td>
    <td>$serviceno</td>
    </tr>
    
    <tr>
    <td colspan='4'>&nbsp;
    </tr>
    
    <tr>
    <td>From Place : </td>
    <td>$src</td>
    
    <td>To Place : </td>
    <td>$dest</td>
    </tr>
    
    <tr>
    <td colspan='4'>&nbsp;
    </tr>
    
    <tr>
    <td>Departure</td>
    <td>$start</td>
    
    <td>Reach</td>
    <td>$reach</td>
    </tr>
    
    </table>";
    
    
    echo"<fieldset style='width:60%;margin-left:15%;margin-top:20px'> 
         <table  align='center' style='padding:0;'>
    <tr>
     <td style='width:10%'>Sex </td>
    <td style='width:30%'> Name </td>
    <td style='width:20%'> Age  </td>
    <td style='width:40%'> Seat no.</td>
    </tr>";
    $b="";
    
    for($i=0;$i<$n;$i++)
    {
     echo "
     <tr>
     <td style='width:30%'> $sex[$i]</td>   
     <td style='width:30%'> $names[$i]</td>
     <td style='width:30%'> $ages[$i]</td>   
     <td style='width:30%'> $arr[$i] </td>
     </tr>";
     $b="".$b.$arr[$i].",";
    }
    
    
    echo"    
    </table>
    </fieldset>";
    echo "<div style='padding-left:15%;margin-top:20px;'> Fare : "." $fare"."</div>";
    echo"
    </fieldset>";

    
}
?>

<?
echo "<br><br>";
echo "<center><form><input type='button' value='Click me!' onclick='printpage()' /></form></center>";
?>

<?
$mhash="6717554c-b44a-48bf-ad8b-49eb12b5d712";
function xml2assoc($xml) {
    $tree = null;
    while($xml->read())
        switch ($xml->nodeType) {
            case XMLReader::END_ELEMENT: return $tree;
            case XMLReader::ELEMENT:
                $node = array('tag' => $xml->name, 'value' => $xml->isEmptyElement ? '' : xml2assoc($xml));
                if($xml->hasAttributes)
                    while($xml->moveToNextAttribute())
                        $node['attributes'][$xml->name] = $xml->value;
                $tree[] = $node;
                break;
            case XMLReader::TEXT:
            case XMLReader::CDATA:
                $tree .= $xml->value;
        }
    return $tree;
}

function pushMessage($mobilehash,$message,$appkey,$pubkey) {
	$head = "<html><head><title>push message</title><meta name='txtweb-appkey' content='$appkey'/></head><body>";
	$tail = "</body></html>";
	$message = $head.$message.$tail;
	$data = array();
	$data['post'] = array(
                          'txtweb-mobile' => $mobilehash,
                          'txtweb-message' => stripslashes($message),
                          'txtweb-pubkey' => $pubkey,
                          );
	$response = xhttp::fetch("http://api.txtweb.com/v1/push", $data);
    
    
	//Check response from push api
	$r = new XMLReader();
	$r->xml($response['body']);
	$res = xml2assoc($r);
    
	$status = $res[0]['value'][0]['value'][0]['value'];
    //	$message = 
    
	return $status; //0 => success, non-zero => push failed
}


$q="Service no: "."$serviceno"."<br>"." From: "."$src"."<br>"."To: "."$dest"."<br>"."Departure: "."$start"."<br>"."Reach: "."$reach"."<br>"."Fare: "."$fare"."<br>"."Seats: "."$b"."<br>";

$msg=$q;


$appkey = "713a2c3b-fb57-4f91-a6b1-3328bb3a30b0";
$pubkey = "10809ed2-8b1b-455f-9250-c1fa91beed01";
print "<html><head><title>push message</title><meta name='txtweb-appkey' content='$appkey'/></head>				    <body>";



$result = pushMessage($mhash, $msg, $appkey,$pubkey);

if ($result == 0)
{
    //print "Message sent successfully! "."</br>";
    $count++;
}

else if ( $result == -1)
{
    //try again
    $try_result = pushMessage($user_mobile, $user_message, 	$appkey, $pubkey);
    print "Result after trying again ".$try_result ;
}

else 
{
    $error++;
    //print "!!!Error occured!!!<br/>Error code : ".$result;
}




print "</body></html>";



$message = "<html><body>\n";
$message .="<div style='height:15%;background-color:lightblue;'><h1> Confirmation Ticket</h1></div> \n";
$message .="<fieldset style='width:75%;margin-left:10%;margin-top:20px'>\n";
$message .="<table width='70%' align= 'center' style='margin-top:20px' >\n";
$message .="<tr><td>Service no</td><td>$serviceno</td></tr>\n";
$message .="<tr><td colspan='4'>&nbsp;</tr>\n";
$message .="<tr><td>From Place : </td><td>$src</td><td>To Place : </td><td>$dest</td></tr>\n";
$message .="<tr><td colspan='4'>&nbsp;</tr>\n";
$message .="<tr><td>Departure</td><td>$start</td><td>Reach</td><td>$reach</td></tr>\n";
$message .="</table>\n";



$message .="<fieldset style='width:60%;margin-left:15%;margin-top:20px'>\n"; 
$message .="<table  align='center' style='padding:0;'>";
$message .="<tr><td style='width:10%'>Sex </td><td style='width:30%'> Name </td><td style='width:20%'> Age  </td>\n";
$message .="<td style='width:40%'> Seat no.</td></tr>\n";
$message .="$b=''\n";
$message .="for($i=0;$i<$n;$i++){\n";
$message .="<tr><td style='width:30%'> $sex[$i]</td><td style='width:30%'> $names[$i]</td><td style='width:30%'> $ages[$i]</td>\n";   
$message .="<td style='width:30%'> $arr[$i] </td></tr>\n";
$message .="}\n";
$message .=" </table></fieldset>\n";
$message .="<div style='padding-left:15%;margin-top:20px;'> Fare : \n";
$message .=" $fare\n";
$message .="</div>\n";
$message .="</fieldset>\n";

$message .="$sex[0]\n";
$message .="$arr[0]\n";
$message .="</body>\n";
$message .="</html>\n";


$to = 'sriharsha.lagisetty@gmail.com';
$subject = 'Confirmation Ticket';


$headers = "From: " . "sriharsha.lagisetty@yahoo.com" . "\r\n";
$headers .= "Reply-To: "."sriharsha.lagisetty@yahoo.com". "\r\n";
$headers .= "CC:sriharsha.lagisetty@gmail.com\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";


mail($to, $subject, $message, $headers);

?>


</body>
</html>














