<?
session_start();
$user_check=$_SESSION['login_user'];
?>

<html>
<body>


<?

$db=mysql_connect("127.0.0.1");
mysql_select_db("test",$db);
$query="select * from images where un='$user_check'";
$result = mysql_query($query);

if(mysql_num_rows($result)>0)
{
    echo "<h3> These files have been uploaded</h3>";
    echo"<ol type='1'>";
    for ($i=0; $i<mysql_num_rows($result);$i++)
    {
        $name=mysql_result($result, $i,"name");
        echo "<li><a href='print.php?name=$name' target='_blank'> $name </a></li>";
        echo"<br>";
    }

echo "</ol>";
}

else
{
    echo "You have not uploaded any files...";
}





?>


