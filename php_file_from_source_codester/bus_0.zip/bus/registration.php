<?
$fn = $_POST['fn'];
$ln = $_POST['ln'];
$un = $_POST['usr'];
$pd = $_POST['pwd'];
$cpd = $_POST['cpwd'];
$sex = $_POST['sex'];
$tel =$_POST['phone'];
$emailid = $_POST['altemail'];
$question = $_POST['question'];
$ans =$_POST['ans'];
$accept =$_POST['accept'];


$link="<a href='form.html' target='_blank'> Login </a>";

if($fn ==''||$ln ==''||$un ==''||$pd ==''||$cpd ==''||$tel ==''||$emailid ==''||$question ==''||$ans =='' )//checking not null
{
    echo "<center>Please enter all the details</center>"."<br>";
    exit;
}
if($accept != 1)
{
    echo "<center>Accept the terms </center>"."<br>";
    exit;
}


$db=mysql_connect("127.0.0.1");
mysql_select_db("test",$db);



if($pd != $cpd )//to check
{
    echo "<center>Password does not match</center>"."<br>";
    exit;
    
}
else
{
    
    $query ="select * from registration where un='$un'";
    $result = mysql_query($query);
    
    if(mysql_num_rows($result)==1)//to check
    {
        echo "<center>User Name already exists &nbsp;&nbsp;</center>";
        echo "<center>Try another... </center>";
        exit;

        
    }
    else
    {
        $query = "insert into registration values('$fn','$ln','$un','$pd','$cpd','$sex','$tel','$emailid','oopo','$question','$ans')";//insertion of values
        mysql_query($query);
       echo "<center>Successful Registartion &nbsp;"."$link"."</center>";
       
        

        

    }
    

}

?>






















