<?
$db=mysql_connect("127.0.0.1");
mysql_select_db("test",$db);

$query ="select * from txt";
$result = mysql_query($query);

for ($i=0; $i<mysql_num_rows($result);$i++)
{
    $num=mysql_result($result, $i,"mhash");
    echo "$num"."<br>";
}
