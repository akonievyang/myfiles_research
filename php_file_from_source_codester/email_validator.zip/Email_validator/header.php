<!DOCTYPE html>
<html lang="en">
    <head>

        <title>Email_Validator</title>
   
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
            
    </head>
 

