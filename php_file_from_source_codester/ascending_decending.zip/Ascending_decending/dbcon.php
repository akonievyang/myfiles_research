<?php
mysql_select_db('asc_desc',mysql_connect('localhost','root',''))or die(mysql_error());
?>