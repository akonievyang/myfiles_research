<?php include('header.php'); ?>
<body>

    <div class="row-fluid">
        <div class="span12">


         

            <div class="container">

<br><br>
						<label>Order by:</label>
						<a class="btn btn-info" href="ascending.php">Ascending</a>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<a class="btn btn-success" href="decending.php">Decending</a>
						<br>
						<br>
                        <table  class="table table-striped table-bordered">
                         
                            <thead>
						
                                <tr>
                                
                                    <th>FirstName</th>
                                    <th>LastName</th>
                                    <th>MiddleName</th>
                                    <th>Address</th>
                                    <th>Email</th>
                                </tr>
                            </thead>
                            <tbody>
							<?php 
							$query=mysql_query("select * from member order by firstname ASC")or die(mysql_error());
							while($row=mysql_fetch_array($query)){
							$id=$row['member_id'];
							?>
                              
										<tr>
									
                                         <td><?php echo $row['firstname'] ?></td>
                                         <td><?php echo $row['lastname'] ?></td>
                                         <td><?php echo $row['middlename'] ?></td>
                                         <td><?php echo $row['address'] ?></td>
                                         <td><?php echo $row['email'] ?></td>
                                </tr>
                         
						          <?php } ?>
                            </tbody>
                        </table>
						
          
</form>

        </div>
        </div>
        </div>
    </div>



</body>
</html>


